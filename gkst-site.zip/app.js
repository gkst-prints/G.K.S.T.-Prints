(() => {
"use strict";
const $ = (s, r = document) => r.querySelector(s);
const KEY = "gkst_cart";                                   // cart is saved as { productId: quantity }
const load = () => { try { return JSON.parse(localStorage.getItem(KEY)) || {}; } catch (e) { return {}; } };
const save = c => { try { localStorage.setItem(KEY, JSON.stringify(c)); } catch (e) {} badge(); };
const money = n => "$" + n.toFixed(2);
const esc = t => String(t).replace(/[&<>"]/g, ch => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[ch]));
const clamp = v => { v = Math.floor(Number(v)); return Number.isFinite(v) ? Math.min(99, Math.max(1, v)) : 1; };
const CATALOG = [];                                        // every buyable item, one entry per color option
PRODUCTS.forEach(p => {
  if (p.soon) return;
  if (p.variants) p.variants.forEach(v => CATALOG.push({ id: p.id + ":" + v.key, name: `${p.name} (${v.label})`, price: v.price, image: v.image, stripe: v.stripe || "" }));
  else CATALOG.push({ id: p.id, name: p.name, price: p.price, image: p.image, stripe: p.stripe || "" });
});
const lines = () => Object.entries(load()).map(([id, q]) => ({ p: CATALOG.find(i => i.id === id), q })).filter(l => l.p && l.q > 0);
const count = () => lines().reduce((s, l) => s + l.q, 0);
const subtotal = () => lines().reduce((s, l) => s + l.p.price * l.q, 0);
const shipping = () => lines().length ? SITE.shipping : 0;
const total = () => subtotal() + shipping();
let lastN = -1;
function badge() {
  const b = $("#badge"), n = count();
  if (b) { b.textContent = n; b.hidden = !n; if (lastN >= 0 && n !== lastN && n) { b.classList.remove("pop"); void b.offsetWidth; b.classList.add("pop"); } }
  lastN = n;
}

/* ---------- page frame ---------- */
const page = document.body.dataset.page;
const prod = page === "product" ? PRODUCTS.find(p => p.id === new URLSearchParams(location.search).get("id")) : null;
const navKey = page === "product" ? (prod ? prod.cat : "fidgets") : page;
const NAV = [["home","index.html","Home"],["fidgets","fidgets.html","Fidgets"],["bmx-parts","bmx-parts.html","BMX Parts"],["custom-prints","custom-prints.html","Custom Prints"],["cart","cart.html","Cart"],["checkout","checkout.html","Checkout"]];
const TITLES = { home: SITE.name, fidgets: "Fidgets", "bmx-parts": "BMX Parts", "custom-prints": "Custom Prints", cart: "Your Cart", checkout: "Checkout" };
const TITLE = page === "product" ? (prod ? prod.name : "Not found") : TITLES[page];
$("#app").innerHTML = `<div class="bar"><a class="brand" href="index.html">${esc(SITE.name)}</a>${NAV.map(([k, h, l]) =>
  `<a class="nav${k === navKey ? " on" : ""}" href="${h}"${k === navKey ? ' aria-current="page"' : ""}>${l}${k === "cart" ? ' <b id="badge" hidden></b>' : ""}</a>`).join("")}</div>
<header class="hero"><h1>${esc(TITLE)}</h1></header><main id="main"></main>`;
document.title = SITE.name + " - " + TITLE;
const main = $("#main");
badge();
window.addEventListener("storage", e => { if (e.key === KEY) { badge(); if (page === "cart") renderCart(); if (page === "checkout") items(); } });

/* ---------- home ---------- */
if (page === "home") {
  main.innerHTML = `<p class="lead">${esc(SITE.tagline)}</p><div class="cats">${[["fidgets.html","Fidgets"],["bmx-parts.html","BMX Parts"],["custom-prints.html","Custom Prints"]].map(([h, l]) => `<a class="cat" href="${h}">${l}</a>`).join("")}</div>`;
}

/* ---------- product pages ---------- */
const buy = `<div class="top"><button class="step" data-a="-" aria-label="Remove one">−</button><button class="atc" data-a="add"><span>Add to Cart</span><svg viewBox="0 0 30 30" aria-hidden="true"><path d="M6 16l6 6 12-13"/></svg></button><button class="step" data-a="+" aria-label="Add one">+</button></div><input class="box" type="number" inputmode="numeric" min="1" max="99" value="1" aria-label="Amount to add"><p class="cap" aria-live="polite"></p>`;
const pic = (src, alt) => `<img src="${esc(src)}" alt="${esc(alt)}" onload="this.classList.add('ld')">`;
const from = p => { const ps = (p.variants || [p]).map(v => v.price), lo = Math.min(...ps); return (lo !== Math.max(...ps) ? "From " : "") + money(lo); };
function card(p) {
  const img = `<div class="img">${p.image ? pic(p.image, p.name) : `<span>${esc(p.name[0])}</span>`}</div>`;
  if (p.soon) return `<article class="card soon">${img}<h3>${esc(p.name)}</h3><p class="desc">Coming soon</p></article>`;
  if (p.variants) return `<a class="card" href="product.html?id=${encodeURIComponent(p.id)}">${img}<h3>${esc(p.name)}</h3><p class="pr">${from(p)}</p><p class="desc">${p.variants.length} colors</p></a>`;
  return `<article class="card" data-id="${esc(p.id)}">${img}<h3>${esc(p.name)}</h3>${p.desc ? `<p class="desc">${esc(p.desc)}</p>` : ""}<p class="pr">${money(p.price)}</p>${buy}</article>`;
}
const cap = c => { const b = $(".box", c); if (b) $(".cap", c).textContent = clamp(b.value || 1) + " will be added to your cart"; };
main.addEventListener("click", e => {                        // shared by every Add to Cart control
  const b = e.target.closest("button[data-a]"); if (!b) return;
  const c = b.closest("[data-id]"), box = $(".box", c), a = b.dataset.a;
  if (a === "-") box.value = clamp(Number(box.value) - 1);
  else if (a === "+") box.value = clamp(Number(box.value) + 1);
  else {
    const cart = load(), id = c.dataset.id;
    cart[id] = Math.min(99, (cart[id] || 0) + clamp(box.value)); save(cart); box.value = 1;
    if (!b.dataset.busy) {                                   // swirl into a check, hold, return (about 1 second)
      b.dataset.busy = 1; b.classList.add("ok");
      setTimeout(() => { b.classList.remove("ok"); delete b.dataset.busy; }, 1000);
    }
  }
  cap(c);
});
main.addEventListener("input", e => { if (e.target.matches(".box")) cap(e.target.closest("[data-id]")); });
main.addEventListener("change", e => { if (e.target.matches(".box")) { e.target.value = clamp(e.target.value); cap(e.target.closest("[data-id]")); } });

if (["fidgets", "bmx-parts", "custom-prints"].includes(page)) {
  const ps = PRODUCTS.filter(p => p.cat === page);
  main.innerHTML = ps.length ? `<div class="products">${ps.map(card).join("")}</div>` : `<p class="empty">New items are coming soon.</p>`;
  main.querySelectorAll(".card[data-id]").forEach(cap);
}

if (page === "product") {
  const vs = prod && !prod.soon && prod.variants;
  if (!vs) main.innerHTML = `<p class="empty">We couldn’t find that item. <a href="fidgets.html">Back to Fidgets</a></p>`;
  else {
    main.innerHTML = `<div class="pd"><div class="gal" id="gal" tabindex="0" role="group" aria-roledescription="carousel" aria-label="${esc(prod.name)} colors"><div class="stage">${vs.map((v, i) => `<img class="slide${i ? "" : " on"}" src="${esc(v.image)}" alt="${esc(prod.name + " in " + v.label)}">`).join("")}</div><button class="arrow prev" aria-label="Previous color">‹</button><button class="arrow next" aria-label="Next color">›</button></div>
<div class="info" id="info"><h2 class="swap" id="pname"></h2><p class="pprice swap" id="pprice"></p><div class="sw" id="sw" role="group" aria-label="Choose a color">${vs.map((v, i) => `<button class="dot" data-i="${i}" style="--c:${v.swatch || v.color}" aria-label="${esc(v.label)}"></button>`).join("")}</div>${buy}</div></div>`;
    const slides = [...main.querySelectorAll(".slide")], dots = [...main.querySelectorAll(".dot")], info = $("#info"), pd = $(".pd"), g = $("#gal");
    let cur = 0;
    const swap = (el, t) => {                                 // fade out, change the text, fade back in
      if (el.textContent === t) return;
      clearTimeout(el._t); el.classList.add("out");
      el._t = setTimeout(() => { el.textContent = t; el.classList.remove("out"); }, 140);
    };
    const show = (i, first) => {
      cur = (i + vs.length) % vs.length;
      const v = vs[cur], n = `${prod.name} (${v.label})`, pr = money(v.price);
      slides.forEach((s, k) => s.classList.toggle("on", k === cur));
      dots.forEach((d, k) => d.setAttribute("aria-pressed", k === cur));
      pd.style.setProperty("--accent", v.color);
      info.dataset.id = prod.id + ":" + v.key;
      if (first) { $("#pname").textContent = n; $("#pprice").textContent = pr; }
      else { swap($("#pname"), n); swap($("#pprice"), pr); }
      cap(info);
    };
    show(0, true);
    $(".arrow.prev").onclick = () => show(cur - 1);
    $(".arrow.next").onclick = () => show(cur + 1);
    $("#sw").addEventListener("click", e => { const d = e.target.closest(".dot"); if (d) show(Number(d.dataset.i)); });
    g.addEventListener("keydown", e => { if (e.key === "ArrowLeft") show(cur - 1); if (e.key === "ArrowRight") show(cur + 1); });
    let x0 = null;                                            // swipe on touch screens
    g.addEventListener("pointerdown", e => { x0 = e.clientX; });
    g.addEventListener("pointerup", e => { if (x0 !== null && Math.abs(e.clientX - x0) > 45) show(cur + (e.clientX < x0 ? 1 : -1)); x0 = null; });
  }
}

/* ---------- cart screen ---------- */
function renderCart() {
  const ls = lines();
  main.innerHTML = ls.length
    ? `<div class="panel">${ls.map(({ p, q }) => `<div class="item"><strong>${esc(p.name)}</strong><span class="line">${money(p.price * q)}<button data-rm="${esc(p.id)}">Remove</button></span><small>${q} × ${money(p.price)}</small></div>`).join("")}<div class="tot"><span>Subtotal</span><span>${money(subtotal())}</span></div></div><a class="go" href="checkout.html">Go to checkout</a>`
    : `<p class="empty">Your cart is empty. Items you add will show up here.</p>`;
}
if (page === "cart") {
  renderCart();
  main.addEventListener("click", e => { const b = e.target.closest("[data-rm]"); if (!b) return; const c = load(); delete c[b.dataset.rm]; save(c); renderCart(); });
}

/* ---------- checkout ---------- */
const orderId = "GKST-" + Date.now().toString(36).toUpperCase();
const $v = id => $("#" + id).value.trim();
function items() {
  const ls = lines();
  $("#items").innerHTML = ls.length ? ls.map(({ p, q }) => `<div class="item co"><div><strong>${esc(p.name)}</strong><br><small>${money(p.price)} each</small></div>
<div class="qty"><button type="button" data-id="${esc(p.id)}" data-d="-1" aria-label="Remove one ${esc(p.name)}">−</button><span>${q}</span><button type="button" data-id="${esc(p.id)}" data-d="1" aria-label="Add one ${esc(p.name)}">+</button></div>
<div class="price">${money(p.price * q)}</div></div>`).join("") : `<p class="note">Your cart is empty. <a href="index.html">Browse the shop</a>.</p>`;
  $("#sub").textContent = money(subtotal()); $("#ship").textContent = money(shipping()); $("#tot").textContent = money(total());
}
function check() {
  if (!lines().length) return "Add at least one item to your cart first.";
  if (!$v("name") || !$v("addr") || !$v("city") || !$v("zip")) return "Please fill in your name and shipping address.";
  if (!/^[A-Za-z]{2}$/.test($v("state"))) return "Enter your state as two letters, like DE.";
  if (!/^\S+@\S+\.\S+$/.test($v("email"))) return "Enter a valid email address.";
  return "";
}
const summaryText = () => lines().map(l => `${l.q} x ${l.p.name}`).join(", ") + ` | ${$v("name")}, ${$v("addr")}, ${$v("city")} ${$v("state").toUpperCase()} ${$v("zip")}`;
const msg = (t, ok) => { const m = $("#msg"); m.style.color = ok ? "var(--ink)" : "var(--err)"; m.textContent = t; };

if (page === "checkout") {
  main.innerHTML = `<div class="co-grid"><div><section><h2>Your order</h2><div id="items"></div></section><section><h2>Shipping details</h2>
<div class="row"><label>Full name<input id="name" autocomplete="name"></label><label>Email<input id="email" type="email" autocomplete="email"></label></div>
<label>Street address<input id="addr" autocomplete="address-line1"></label>
<div class="row3"><label>City<input id="city" autocomplete="address-level2"></label><label>State<input id="state" maxlength="2" placeholder="DE" autocomplete="address-level1"></label><label>ZIP code<input id="zip" autocomplete="postal-code"></label></div>
<label>Order notes (optional)<textarea id="notes" rows="2" placeholder="Colors, sizes, anything we should know"></textarea></label></section></div>
<aside class="sum"><h2>Summary</h2><dl><dt>Subtotal</dt><dd id="sub"></dd><dt>Shipping</dt><dd id="ship"></dd><dt class="t">Total</dt><dd class="t" id="tot"></dd></dl>
<div class="tabs" id="tabs" role="tablist" aria-label="Payment method"></div>
<div id="p-card" hidden><button class="btn" id="cardBtn">Pay by card</button><p class="note">You’ll finish on Stripe’s secure card page. We never see your card number.</p></div>
<div id="p-paypal" hidden><div id="pp"></div><p class="note">Pay with PayPal, or with a debit or credit card through PayPal.</p></div>
<div id="p-cash" hidden><button class="btn" id="cashBtn">Pay with Cash App</button><p class="note">Cash App opens with the total filled in. Please keep the order number in the note.</p></div>
<p class="msg" id="msg" role="alert"></p></aside></div>`;
  items();
  $("#items").addEventListener("click", e => {
    const b = e.target.closest("button"); if (!b) return;
    const c = load(), id = b.dataset.id, n = Math.min(99, Math.max(0, (c[id] || 0) + Number(b.dataset.d)));
    if (n) c[id] = n; else delete c[id];
    save(c); msg(""); items();
  });

  const methods = [];
  if (CATALOG.some(i => i.stripe)) methods.push(["card", "Card"]);
  if (SITE.paypalClientId) methods.push(["paypal", "PayPal"]);
  if (SITE.cashTag) methods.push(["cash", "Cash App"]);
  const pick = k => { methods.forEach(([m]) => { $("#p-" + m).hidden = m !== k; }); $("#tabs").querySelectorAll("button").forEach(b => b.setAttribute("aria-selected", b.dataset.k === k)); msg(""); };
  $("#tabs").innerHTML = methods.map(([k, l]) => `<button type="button" role="tab" data-k="${k}">${l}</button>`).join("");
  $("#tabs").addEventListener("click", e => { const b = e.target.closest("button"); if (b) pick(b.dataset.k); });
  if (methods.length) pick(methods[0][0]);

  const finish = () => {
    const name = $v("name").split(" ")[0]; save({});
    main.innerHTML = `<div class="done"><h2>Thank you, ${esc(name)}!</h2><p>Your order <strong>${orderId}</strong> is in. A receipt is on its way to your email.</p><p><a href="index.html">Back to the shop</a></p></div>`;
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  $("#cardBtn").addEventListener("click", () => {               // Stripe Payment Link: one product per card order
    const err = check(); if (err) return msg(err);
    const ls = lines();
    if (ls.length > 1 || !ls[0].p.stripe) return msg("Card checkout handles one product at a time. Pay with PayPal for a mixed order, or order each item separately.");
    const u = new URL(ls[0].p.stripe);
    u.searchParams.set("prefilled_email", $v("email")); u.searchParams.set("client_reference_id", orderId);
    location.href = u.toString();
  });

  $("#cashBtn").addEventListener("click", () => {
    const err = check(); if (err) return msg(err);
    window.open(`https://cash.app/${SITE.cashTag.replace(/^\$?/, "$")}/${total().toFixed(2)}`, "_blank", "noopener");
    if (navigator.clipboard) navigator.clipboard.writeText(`Order ${orderId}: ${summaryText()}`).catch(() => {});
    msg(`Use order number ${orderId} as your Cash App note. Your order details were copied.`, true);
  });

  if (SITE.paypalClientId) {
    const s = document.createElement("script");
    s.src = `https://www.paypal.com/sdk/js?client-id=${encodeURIComponent(SITE.paypalClientId)}&currency=${SITE.currency}&components=buttons&enable-funding=card`;
    s.onload = () => paypal.Buttons({
      style: { layout: "vertical", color: "blue", shape: "rect", label: "pay" },
      onClick: (d, a) => { const err = check(); msg(err); return err ? a.reject() : a.resolve(); },
      createOrder: (d, a) => a.order.create({ purchase_units: [{
        reference_id: orderId, custom_id: orderId, description: ("GKST " + summaryText()).slice(0, 127),
        amount: { currency_code: SITE.currency, value: total().toFixed(2), breakdown: {
          item_total: { currency_code: SITE.currency, value: subtotal().toFixed(2) },
          shipping: { currency_code: SITE.currency, value: shipping().toFixed(2) } } },
        items: lines().map(l => ({ name: l.p.name.slice(0, 127), quantity: String(l.q), unit_amount: { currency_code: SITE.currency, value: l.p.price.toFixed(2) } })),
        shipping: { name: { full_name: $v("name") }, address: { address_line_1: $v("addr"), admin_area_2: $v("city"), admin_area_1: $v("state").toUpperCase(), postal_code: $v("zip"), country_code: "US" } }
      }] }),
      onApprove: (d, a) => a.order.capture().then(finish),
      onError: () => msg("PayPal couldn’t finish that payment. Nothing was charged, so please try again.")
    }).render("#pp");
    s.onerror = () => msg("PayPal couldn’t load. Check your connection and refresh the page.");
    document.head.appendChild(s);
  }
}
})();
