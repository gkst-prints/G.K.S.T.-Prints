/* ================================================================
   THE ONLY FILE YOU NEED TO EDIT. Add a product by copying one
   { ... }, line and changing it. Keep the comma at the end.

   id     short unique code, no spaces (every product needs its own)
   cat    which page it shows on: "fidgets", "bmx-parts" or "custom-prints"
   name   what customers see
   price  price for ONE item, numbers only (12 or 12.50, no $ sign)
   desc   one short line under the name (can be "")
   image  picture file in this folder, like "pedals.jpg" (or "" for none)
   stripe optional Stripe Payment Link for card payments (or "")

   Items with color options use a  variants: [ ... ]  list instead of price/image
   (see Gyro-Star below): key = short code, label = shown in the name, price, image,
   color = accent color for that option, swatch = optional CSS background for its dot.
   soon: true  shows a greyed "Coming soon" card.
   ================================================================ */
const SITE = {
  name: "G.K.S.T. Prints",
  tagline: "3D printed fidgets, BMX parts and custom prints.",   // edit me
  paypalClientId: "ARJJqO4LAfKe9M_3n6cagIs5CBzSskNrf6u33JRnOLRwtJCKqG5-cP2BGSY9Ahzhc9dLekSsz5ZkzaI1",
  currency: "USD",
  shipping: 5.00,      // flat shipping per order: set this to your average Pirate Ship cost
  cashTag: ""          // optional, like "$GKSTPrints". "" hides Cash App
};

const PRODUCTS = [
  { id: "gyro-star", cat: "fidgets", name: "Gyro-Star", image: "images/gyro-star-red.jpg", variants: [
    { key: "red",   label: "Red",           price: 9.00, image: "images/gyro-star-red.jpg",   color: "#ff4a3a", stripe: "" },
    { key: "blue",  label: "Blue",          price: 9.00, image: "images/gyro-star-blue.jpg",  color: "#3d8bff", stripe: "" },
    { key: "green", label: "Green",         price: 9.00, image: "images/gyro-star-green.jpg", color: "#2fd46b", stripe: "" },
    { key: "bw",    label: "Black & White", price: 9.50, image: "images/gyro-star-bw.jpg",    color: "#ffffff", swatch: "linear-gradient(135deg,#fff 50%,#111 50%)", stripe: "" }
  ] },
  { id: "fidget-2", cat: "fidgets", name: "Fidget 2", soon: true },
  { id: "fidget-3", cat: "fidgets", name: "Fidget 3", soon: true },
  { id: "fidget-4", cat: "fidgets", name: "Fidget 4", soon: true }
];
